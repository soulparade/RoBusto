namespace RoBusto;

using System.IO.Ports;

public class Pannello_Di_Comunicazione
{
	static SerialPort _serialPort;

	public static RoBusto roBusto = RoBusto.DeserializeRoBusto("Test");

	public void Comunicazione()
	{
		_serialPort = new SerialPort(portName: "COM3", baudRate: 9600);

		try
		{
			_serialPort.Open();

			if (_serialPort.IsOpen)
			{
				//Thread thread1 = new Thread(ReadFromSerial);
				Thread thread2 = new Thread(WriteToSerial);

				//thread1.Start();
				thread2.Start();
			}
		} catch (Exception ex)
		{
			Console.WriteLine("Si è verificato un'errore durante l'apertura della porta seriale: " + ex.Message);
		}


	}

	static void ReadFromSerial()
	{
		while (true)
		{
			try
			{
				string stato = _serialPort.ReadExisting();
				if (stato != null)
				{
					double value = Convert.ToDouble(stato);

					Console.WriteLine(value);
				}
				Thread.Sleep(500);

			} catch (TimeoutException) { } catch (Exception ex)
			{
				Console.WriteLine("Errore durante la lettura dalla porta seriale: " + ex.Message);
			}
		}
	}

	public static void WriteToSerial()
	{
		string[] movimenti = { "apri", "chiudi", "vittoria", "ok", "saluto", "apribicipite", "chiudibicipite", "apribraccio", "chiudibraccio", "spallaadx", "spallaasx", "spallasu", "spallagiu", "assenso", "diniego", "salutobraccio" };
		_serialPort.WriteLine("handDx");
		while (true)
		{
			try
			{
				Console.WriteLine("Inserire operazione richiesta( end per terminare ): ");
				foreach (string movimento in movimenti)
				{

					Console.WriteLine($" -{movimento}");
				}
				string movimentoScelto = Console.ReadLine()!;

				if (movimentoScelto.ToLower().Equals("end"))
				{
					Console.WriteLine("\nInserimento disattivato");
					break;
				}

				foreach (string movimento in movimenti)
				{

					if (movimentoScelto.ToLower().Equals(movimento))
					{

						_serialPort.WriteLine(movimento);
						Console.WriteLine("\nMovimento inviato: " + movimento);
					}
				}

			} catch (Exception ex)

			{
				Console.WriteLine("Errore durante la scrittura sulla porta seriale: " + ex.Message);
			}
		}
	}
}
