namespace RoBusto;


public class Testa(List<Dito> servi)
{
	public List<Dito> servi { get; set; } = servi;

}
