namespace RoBusto;

public class Manichino
{

	public int angMax { get; set; }
	public int angMin { get; set; }
	public int angAtt { get; set; }

	public void inizializza(int angMax, int angMin, int angAtt)
	{
		this.angMax = angMax;
		this.angMin = angMin;
		this.angAtt = angAtt;
	}

	public int modifica(int parametro, int valore)
	{
		parametro = valore;
		return parametro;
	}
}
