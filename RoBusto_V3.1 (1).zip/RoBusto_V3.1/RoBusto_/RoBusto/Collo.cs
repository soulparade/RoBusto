namespace RoBusto;


public class Collo(List<Dito> servi)
{
	public List<Dito> servi { get; set; } = servi;

}
