namespace RoBusto;

public class Gomito : Servo
{
	public string nome { get; set; }
	public Gomito(int angMax, int angMin, int angAtt, int pin, string nome) : base(angMax, angMin, angAtt, pin) => this.nome = nome;
}
