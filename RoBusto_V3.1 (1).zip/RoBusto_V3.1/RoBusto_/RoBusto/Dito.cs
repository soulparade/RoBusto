namespace RoBusto;
public class Dito : Servo
{
	public string nome { get; set; }
	public Dito(int angMax, int angMin, int angAtt, int pin, string nome) : base(angMax, angMin, angAtt, pin) => this.nome = nome;

}
