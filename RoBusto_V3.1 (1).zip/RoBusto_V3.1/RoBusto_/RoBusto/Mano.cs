namespace RoBusto;
public class Mano(List<Dito> dita)
{
	public List<Dito> dita { get; set; } = dita;

}
