namespace RoBusto;
using System;
using System.Text.Json;

public class RoBusto(string nome, Testa testa, Collo collo, Busto busto)
{

	public string nome { get; init; } = nome;

	public Testa testa { get; init; } = testa;
	public Collo collo { get; init; } = collo;
	public Busto busto { get; init; } = busto;


	public static void SerializeAndSaveRoBusto(RoBusto roBusto, string fileName)
	{
		var pathJson = Path.GetFullPath(fileName);
		Console.WriteLine(pathJson);
		var text = JsonSerializer.Serialize(roBusto);
		File.WriteAllText(pathJson + ".json", text);
	}

	public static RoBusto DeserializeRoBusto(string fileName)
	{
		var pathJson = Path.GetFullPath(fileName);
		var jsonStr = File.ReadAllText(pathJson + ".json");
		var options = new JsonSerializerOptions { IncludeFields = true };
		return JsonSerializer.Deserialize<RoBusto>(jsonStr, options)!;
	}
}
