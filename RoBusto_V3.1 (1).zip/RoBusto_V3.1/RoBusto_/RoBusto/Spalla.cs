namespace RoBusto;

public class Spalla(List<Dito> servi)
{
	public List<Dito> servi { get; set; } = servi;
}
