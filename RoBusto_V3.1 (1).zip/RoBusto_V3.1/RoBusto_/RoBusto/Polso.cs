namespace RoBusto;

public class Polso : Servo
{
	public string nome { get; set; }
	public Polso(int angMax, int angMin, int angAtt, int pin, string nome) : base(angMax, angMin, angAtt, pin) => this.nome = nome;

	public int angDritto = 120;
}
