namespace RoBusto;

using System.IO.Ports;
using System;

public class Pannello_Di_Comunicazione
{
	static SerialPort _serialPort;

	public static RoBusto roBusto = RoBusto.DeserializeRoBusto("Test");

	public void Comunicazione()
	{
		_serialPort = new SerialPort(portName: "COM4", baudRate: 9600);

		try
		{
			_serialPort.Open();

			if (_serialPort.IsOpen)
			{
				//Thread thread1 = new Thread(ReadFromSerial);
				Thread thread2 = new Thread(WriteToSerial);

				//thread1.Start();
				thread2.Start();
			}
		} catch (Exception ex)
		{
			Console.WriteLine("Si è verificato un'errore durante l'apertura della porta seriale: " + ex.Message);
		}


	}

	static void ReadFromSerial()
	{
		while (true)
		{
			try
			{
				string stato = _serialPort.ReadExisting();
				if (stato != null)
				{
					double value = Convert.ToDouble(stato);

					Console.WriteLine(value);
					
				}
				Thread.Sleep(500);

			} catch (TimeoutException) { } catch (Exception ex)
			{
				Console.WriteLine("Errore durante la lettura dalla porta seriale: " + ex.Message);
			}
		}
	}

	public static void WriteToSerial()
	{
		string[] movimenti = { "apri", "chiudi", "vittoria", "ok", "saluto", "aprib", "chiudib", "apribr", "chiudibr" }; // B = bicipite, Br = braccio

		Console.WriteLine("Inserire quale mano si vuole inviare: 0 destra - 1 sinistra");
		int temp = Convert.ToInt32(Console.ReadLine())!;

		if (temp == 0)
		{
			_serialPort.WriteLine("handDx");
		} else
		{
			_serialPort.WriteLine("handSx");
		}

		while (true)
		{
			try
			{
				Console.WriteLine("Inserire operazione richiesta( end per terminare, change per cambiare la soglia dei sensori magnetici): ");
				foreach (string movimento in movimenti)
				{

					Console.WriteLine($" -{movimento}");
				}
				string movimentoScelto = Console.ReadLine()!;

				if (movimentoScelto.ToLower().Equals("end"))
				{

					Console.WriteLine("\nInserimento disattivato");
					break;
				} else if (movimentoScelto.ToLower().Equals("change"))
				{
					String soglia;
					Console.WriteLine("\nInserisci nuova soglia: ");
					soglia = Console.ReadLine();

					try
					{
						int number = ConvertStringToInt(soglia);
						//Console.WriteLine("Numero convertito: " + number);
						_serialPort.WriteLine("change");
						Thread.Sleep(500);
						_serialPort.WriteLine(soglia);
					} catch (FormatException ex)
					{
						Console.WriteLine("Errore: " + ex.Message);
						//Console.WriteLine("Errore: la stringa inserita non e' un numero intero");
					}
	
				}

				foreach (string movimento in movimenti)
				{

					if (movimentoScelto.ToLower().Equals(movimento))
					{

						_serialPort.WriteLine(movimento);
						Console.WriteLine("\nMovimento inviato: " + movimento);
					}
				}

			} catch (Exception ex)

			{
				Console.WriteLine("Errore durante la scrittura sulla porta seriale: " + ex.Message);
			}
		}
	}
	
	static int ConvertStringToInt(string str)
    {
        if (!int.TryParse(str, out int result))
        {
            throw new FormatException($"La stringa '{str}' non è un numero intero valido.");
        }

        return result;
    }
}
