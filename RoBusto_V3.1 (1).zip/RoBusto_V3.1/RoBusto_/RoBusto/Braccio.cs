namespace RoBusto;
using System.Text.Json;

public class Braccio(string nome, Spalla spalla, Gomito gomito, Polso polso, Mano mano)
{


	public string nome { get; init; } = nome;
	public Spalla spalla { get; init; } = spalla;
	public Gomito gomito { get; init; } = gomito;
	public Polso polso { get; init; } = polso;
	public Mano mano { get; init; } = mano;


	public static void SerializeAndSaveBraccio(Braccio braccio, string fileName)
	{
		var pathJson = Path.GetFullPath(fileName);
		Console.WriteLine(pathJson);
		var text = JsonSerializer.Serialize(braccio);
		File.WriteAllText(pathJson + ".json", text);
	}
	public static Braccio DeserializeBraccio(string fileName)
	{

		var pathJson = Path.GetFullPath(fileName);
		var jsonStr = File.ReadAllText(pathJson + ".json");
		var options = new JsonSerializerOptions { IncludeFields = true };
		return JsonSerializer.Deserialize<Braccio>(jsonStr, options)!;
	}


}


