﻿namespace RoBusto;
using System;
public class Program()
{
	static void Main()
	{

		/*List<Dito> numeri = new List<Dito>();
		numeri.Add(new Dito(0,0,0,0,"ciao") ):
		

		Gomito gomito = new Gomito(0,0,0,0,"ciao");
		Polso polso = new Polso(0,0,0,0,"ciao");

        Braccio gatto = new Braccio( "bracciodx", new Spalla(numeri), gomito, polso, new Mano( numeri ) );


		RoBusto robusto = new RoBusto( "robusto", new Testa( numeri ),new Collo(numeri), new Busto( "busto", gatto, gatto ) );

		RoBusto.SerializeAndSaveRoBusto(robusto, "Test");*/


		RoBusto roBusto = RoBusto.DeserializeRoBusto("Test");
		RoBusto.SerializeAndSaveRoBusto(roBusto, "Test");


		Console.WriteLine("Scegliere il Nome del File di log: ");
		string logFile = Console.ReadLine()!;

		do
		{
			Console.WriteLine("scelta: 0 = modifica robusto / 1 = pannello di comunicazione");
			int scelta = Convert.ToInt32(Console.ReadLine())!;

			if (scelta == 0)    // modifica RoBusto
			{
				esposizioneModificaRoBusto(roBusto, logFile);
				RoBusto.SerializeAndSaveRoBusto(roBusto, "Test");
			}
			if (scelta == 1) // pannello di comunicazione
			{
				RoBusto.SerializeAndSaveRoBusto(roBusto, "Test");
				break;
			}

		} while (true);


		Pannello_Di_Comunicazione pannello = new Pannello_Di_Comunicazione();

		pannello.Comunicazione();
	}

	public static void esposizioneModificaRoBusto(RoBusto roBusto, string logFile)
	{
		string nomeParte = "";
		string nomeSottoparte = "";

		Manichino manichino = new Manichino();

		Console.WriteLine("\n-0 testa\n-1 collo\n-2 busto");
		int scelta = Convert.ToInt32(Console.ReadLine())!;

		switch (scelta)
		{
			case 0:
				foreach (var servo in roBusto.testa.servi)
				{
					nomeParte = "Testa";
					nomeSottoparte = servo.nome;

					Console.WriteLine("Testa:\n");

					Console.WriteLine(servo.nome + ": ");
					Console.WriteLine("\nModificabili: \n0)AngoloMax: " + servo.angMax + "\n1)AngoloMin: " + servo.angMin + "\n2)AngoloAttuale: " + servo.angAtt);

					manichino.inizializza(servo.angMax, servo.angMin, servo.angAtt);
					modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);

					servo.angMax = servo.modifica(servo.angMax, manichino.angMax);
					servo.angMin = servo.modifica(servo.angMin, manichino.angMin);
					servo.angAtt = servo.modifica(servo.angAtt, manichino.angAtt);
				}
				break;
			case 1:
				foreach (var servo in roBusto.collo.servi)
				{
					nomeParte = "Collo";
					nomeSottoparte = servo.nome;

					Console.WriteLine("Collo:\n");

					Console.WriteLine(servo.nome + ": ");
					Console.WriteLine("\nModificabili: \n0)AngoloMax: " + servo.angMax + "\n1)AngoloMin: " + servo.angMin + "\n2)AngoloAttuale: " + servo.angAtt);

					manichino.inizializza(servo.angMax, servo.angMin, servo.angAtt);
					modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);

					servo.angMax = servo.modifica(servo.angMax, manichino.angMax);
					servo.angMin = servo.modifica(servo.angMin, manichino.angMin);
					servo.angAtt = servo.modifica(servo.angAtt, manichino.angAtt);
				}
				break;
			case 2:
				Console.WriteLine("Busto:\n");
				Console.WriteLine("Modificare: 0 braccioDX --- 1 braccioSX ");

				scelta = Convert.ToInt32(Console.ReadLine())!;

				switch (scelta)
				{
					case 0:
						esposizioneModificaParti(roBusto.busto.braccioDX, "DX", logFile);
						break;
					case 1:
						esposizioneModificaParti(roBusto.busto.braccioSX, "SX", logFile);
						break;
				}
				break;
			default:
				Console.WriteLine("Errore switch");
				break;
		}

	}

	public static void esposizioneModificaParti(Braccio braccio, string parte, string logFile)
	{

		string nomeParte = "";
		string nomeSottoparte = "";

		Manichino manichino = new Manichino();

		Console.WriteLine("\n-0 spalla\n-1 gomito\n-2 polso\n-3 mano");
		int scelta = Convert.ToInt32(Console.ReadLine())!;

		switch (scelta)
		{
			case 0:

				foreach (var servo in braccio.spalla.servi)
				{
					nomeParte = $"Spalla{parte}";
					nomeSottoparte = servo.nome;

					Console.WriteLine($"Spalla{parte}:\n");

					Console.WriteLine(servo.nome + ": ");
					Console.WriteLine("\nModificabili: \n0)AngoloMax: " + servo.angMax + "\n1)AngoloMin: " + servo.angMin + "\n2)AngoloAttuale: " + servo.angAtt);

					manichino.inizializza(servo.angMax, servo.angMin, servo.angAtt);
					modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);

					servo.angMax = servo.modifica(servo.angMax, manichino.angMax);
					servo.angMin = servo.modifica(servo.angMin, manichino.angMin);
					servo.angAtt = servo.modifica(servo.angAtt, manichino.angAtt);
				}
				break;
			case 1:

				nomeParte = $"Gomito{parte}";
				nomeSottoparte = braccio.gomito.nome;

				Console.WriteLine($"Gomito {parte}:\n");

				Console.WriteLine("\nModificabili: \n0)AngoloMax: " + braccio.gomito.angMax + "\n1)AngoloMin: " + braccio.gomito.angMin + "\n2)AngoloAttuale: " + braccio.gomito.angAtt);

				manichino.inizializza(braccio.gomito.angMax, braccio.gomito.angMin, braccio.gomito.angAtt);
				modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);

				braccio.gomito.angMax = braccio.gomito.modifica(braccio.gomito.angMax, manichino.angMax);
				braccio.gomito.angMin = braccio.gomito.modifica(braccio.gomito.angMin, manichino.angMin);
				braccio.gomito.angAtt = braccio.gomito.modifica(braccio.gomito.angAtt, manichino.angAtt);

				break;
			case 2:
				nomeParte = $"Polso{parte}";
				nomeSottoparte = "servo";

				Console.WriteLine($"Polso {parte}:\n");

				Console.WriteLine("\nModificabili: \n0)AngoloMax: " + braccio.polso.angMax + "\n1)AngoloMin: " + braccio.polso.angMin + "\n2)AngoloAttuale: " + braccio.polso.angAtt);

				manichino.inizializza(braccio.polso.angMax, braccio.polso.angMin, braccio.polso.angAtt);

				modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);
				braccio.polso.angMax = braccio.polso.modifica(braccio.polso.angMax, manichino.angMax);
				braccio.polso.angMin = braccio.polso.modifica(braccio.polso.angMin, manichino.angMin);
				braccio.polso.angAtt = braccio.polso.modifica(braccio.polso.angAtt, manichino.angAtt);

				break;
			case 3:
				foreach (var servo in braccio.mano.dita)
				{
					nomeParte = $"Mano{parte}";
					nomeSottoparte = servo.nome;

					Console.WriteLine($"Mano{parte}:\n");

					Console.WriteLine(servo.nome + ": ");
					Console.WriteLine("\nModificabili: \n0)AngoloMax: " + servo.angMax + "\n1)AngoloMin: " + servo.angMin + "\n2)AngoloAttuale: " + servo.angAtt);

					manichino.inizializza(servo.angMax, servo.angMin, servo.angAtt);
					modificatoreAttributi(manichino, nomeParte, nomeSottoparte, logFile);

					servo.angMax = servo.modifica(servo.angMax, manichino.angMax);
					servo.angMin = servo.modifica(servo.angMin, manichino.angMin);
					servo.angAtt = servo.modifica(servo.angAtt, manichino.angAtt);
				}
				break;
			default:
				Console.WriteLine("Error");
				break;
		}
	}
	public static void log(string nomeParte, string nomeSottoparte, string nomeParametro, string data, string logfile)
	{
		using (StreamWriter sw = File.AppendText(logfile + ".txt"))
		{
			sw.WriteLine($"{nomeParte} : {nomeSottoparte} : {nomeParametro} : {data}");
		}
	}
	public static void modificatoreAttributi(Manichino manichino, string nomeParte, string nomeSottoparte, string logfile)
	{

		Console.WriteLine("\nModificare qualcosa? Y/N ");
		string modifica = Console.ReadLine()!;

		while (modifica.ToUpper() == "Y")
		{
			Console.WriteLine("cosa si vuole Cambiare?( inserire indice )");
			string parametroDaCambiare = Console.ReadLine()!;

			Console.WriteLine("nuovo valore: ");
			int valore = Convert.ToInt32(Console.ReadLine());

			switch (parametroDaCambiare)
			{
				case "0":
					manichino.angMax = manichino.modifica(manichino.angMax, valore);
					Console.WriteLine("valore nuovo:" + manichino.angMax);

					log(nomeParte, nomeSottoparte, "AngMax", $"{manichino.angMax}", logfile);
					break;
				case "1":
					manichino.angMin = manichino.modifica(manichino.angMin, valore);
					Console.WriteLine("valore nuovo:" + manichino.angMin);

					log(nomeParte, nomeSottoparte, "AngMin", $"{manichino.angMin}", logfile);
					break;
				case "2":
					manichino.angAtt = manichino.modifica(manichino.angAtt, valore);
					Console.WriteLine("valore nuovo:" + manichino.angAtt);

					log(nomeParte, nomeSottoparte, "AngAtt", $"{manichino.angAtt}", logfile);
					break;
				default:
					Console.WriteLine("Errore, switch modifica");
					break;
			}
			Console.WriteLine("\nModificare qualcosa? Y/N ");
			modifica = Console.ReadLine()!;
		}
	}
}
