namespace RoBusto;


public class Busto(string nome, Braccio braccioDX, Braccio braccioSX)
{
	public string nome { get; init; } = nome;
	public Braccio braccioDX { get; init; } = braccioDX;
	public Braccio braccioSX { get; init; } = braccioSX;

}
