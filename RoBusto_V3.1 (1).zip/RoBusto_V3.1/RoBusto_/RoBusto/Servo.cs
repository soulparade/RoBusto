namespace RoBusto;

public class Servo(int angMax, int angMin, int angAtt, int pin)
{
	public int angMax { get; set; } = angMax;
	public int angMin { get; set; } = angMin;
	public int angAtt { get; set; } = angAtt;
	public int pin { get; set; } = pin;

	//string siglaMotore = "JX Servo PDI-6225MG-300";
	//string marca = "JX Servo";

	public int modifica(int parametro, int valore)
	{
		parametro = valore;
		return parametro;
	}

}
